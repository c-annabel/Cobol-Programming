      ******************************************************************
      * Author & ID: CHENG, Annabel  (041146557),
      *              ZHAO,  LingFeng (041162790),
      *              GURTH, Benjamin (041127769).
      * Course and Section: CST8283 311
      * Date: 2025-07-27
      * Purpose: PROJECT 3 C2 SUBROUTINE FOR CALLING FROM P3C1.CBL
      * Tectonics: cbl
      ******************************************************************
       IDENTIFICATION DIVISION.
      ******************************************************************
       PROGRAM-ID. P3C2.
      ******************************************************************
       ENVIRONMENT DIVISION.
      ******************************************************************

      ******************************************************************
       DATA DIVISION.
      ******************************************************************
       WORKING-STORAGE SECTION.
      *Linkage section for arguments called.
       LINKAGE SECTION.
       01 C2-SHARES                  PIC 9(05).
       01 C2-AVG-COST                PIC 9(04)V99.
       01 C2-COST-BASE               PIC 9(07)V99.
       01 C2-MARKET-VALUE            PIC 9(07)V99.
       01 C2-GAIN-LOSS               PIC S9(07)V99.
      ******************************************************************
       PROCEDURE DIVISION USING C2-SHARES,    C2-AVG-COST,
                                C2-COST-BASE, C2-MARKET-VALUE,
                                C2-GAIN-LOSS.
      ******************************************************************
       *> Calculate cost base, market value, and gain/loss for each stock.
         MULTIPLY C2-AVG-COST BY C2-SHARES
                                           GIVING C2-COST-BASE.
         MULTIPLY C2-MARKET-VALUE BY C2-SHARES
                                           GIVING C2-MARKET-VALUE.
         SUBTRACT C2-COST-BASE FROM C2-MARKET-VALUE
                                           GIVING C2-GAIN-LOSS.
         EXIT PROGRAM.
      ******************************************************************
       END PROGRAM P3C2.
      ******************************************************************
