      ******************************************************************
      * Author & ID: CHENG, Annabel  (041146557),
      *              ZHAO,  LingFeng (041162790),
      *              GURTH, Benjamin (041127769).
      * Course and Section: CST8283 311
      * Date: 2025-07-27
      * Purpose: PROJECT 3 B PORTFOLIO CRUD MANAGEMENT VIA SCREEN
      * Tectonics: cobc
      ******************************************************************
       IDENTIFICATION DIVISION.
      ******************************************************************
       PROGRAM-ID. P3B.
      ******************************************************************
       ENVIRONMENT DIVISION.
      ******************************************************************
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
         SELECT STOCKS-IN
           ASSIGN TO "../STOCKS.TXT"
           ORGANIZATION IS LINE SEQUENTIAL
           FILE STATUS  IS STATUS-STOCK.
         SELECT PORTFOLIO-IO
           ASSIGN TO "../PORTFOLIO-INDEXED.DAT"
           ORGANIZATION IS INDEXED
           ACCESS MODE  IS DYNAMIC
           RECORD KEY   IS STOCK-SYMBOL-IO
           FILE STATUS  IS STATUS-PORTFOLIO.
      ******************************************************************
       DATA DIVISION.
      ******************************************************************
      *------------------------*
       FILE SECTION.
      *------------------------*
       FD STOCKS-IN.
       *> Stock record from input file.
       01 STOCKS-RECORD-IN.
           05 STOCK-SYMBOL-IN          PIC X(07).
           05 STOCK-NAME-IN            PIC X(25).
           05 CLOSING-PRICE-IN         PIC 9(04)V99.
       FD PORTFOLIO-IO.
       *> Portfolio record for CRUD operations.
       01 PORTFOLIO-RECORD-IO.
           05 STOCK-SYMBOL-IO          PIC X(07).
           05 SHARES-IO                PIC 9(05).
           05 AVG-COST-PER-SHARE-IO    PIC 9(04)V99.
      *------------------------*
       WORKING-STORAGE SECTION.
      *------------------------*
       *> File status for stocks file.
       01 STATUS-STOCK                 PIC X(02).
       *> File status for portfolio file.
       01 STATUS-PORTFOLIO             PIC X(02).
       *> Loop counter variable.
       01 SUB-1                        PIC 9(03)  VALUE 1.
       *> End-of-file flag.
       01 EOF-FLAG                     PIC X(01)  VALUE 'N'.
          88 EOF-YES                              VALUE 'Y'.
          88 EOF-NO                               VALUE 'N'.
       *> Exit flag for main loop.
       01 EXIT-FLAG                    PIC X(01)  VALUE 'N'.
          88 EXIT-YES                             VALUE 'Y'.
          88 EXIT-NO                              VALUE 'N'.
       *> Line of hyphens for formatting.
       01 HYPHEN-LINE                  PIC X(80)  VALUE ALL "-".
       *> Line of dashes for formatting.
       01 DASH-LINE                    PIC X(80)  VALUE ALL "=".
       *> Blank line for spacing.
       01 BLANK-LINE                   PIC X(80)  VALUE ALL " ".
       *> Table for stock data storage.
       01 STOCKS-TABLE.
          05 STOCKS-VALUE OCCURS 20 TIMES
             ASCENDING KEY IS T-STOCK-SYMBOL
             INDEXED BY STOCK-INDEX.
             10 T-STOCK-SYMBOL         PIC X(07).
             10 T-STOCK-NAME           PIC X(25).
             10 T-CLOSING-PRICE        PIC 9(04)V99.
       *> Record counters.
       01 AUDIT-TRAIL-IN.
          05 RECORDS-READ              PIC 9(03)  VALUE ZERO.
          05 RECORDS-WRITTEN           PIC 9(03)  VALUE ZERO.
       *> Formatted record counters.
       01 AUDIT-TRAIL-OUT.
          05 PRINT-RECORDS-READ        PIC  ZZ9.
          05 PRINT-RECORDS-WRITTEN     PIC  ZZ9.
       *> User menu choice.
       01 USER-CHOICE                  PIC 9(01)  VALUE 0.
          88 SEARCH-1                             VALUE 1.
          88 BUY-2                                VALUE 2.
          88 EXIT-9                               VALUE 9.
          88 HOME-0                               VALUE 0.
       *> Current screen line position.
       01 WS-LINE                      PIC 9(02)  VALUE 10.
       *> Message fields for display.
       01 WS-MESSAGE.
          05 WS-MESSAGE01              PIC X(50).
          05 WS-MESSAGE05              PIC X(50).
       *> Portfolio display border
       01 WS-PORTFOLIO-DISPLAY-LINE.
          05 WS-START-LINE             PIC 9(02) VALUE 10.
          05 WS-END-LINE               PIC 9(02) VALUE 25.
       *> Working stock name.
       01 WS-STOCK-NAME                PIC X(25).
       *> Working closing price.
       01 WS-CLOSING-PRICE             PIC 9(04)V99.
       *> Working shares count.
       01 WS-SHARES                    PIC 9(05).
       *> Total shares calculation.
       01 TOTALSHARES                  PIC 9(05).
      *------------------------*
       SCREEN SECTION.
      *------------------------*
       *> Main menu and input screen layout.
       01 MAIN-SCREEN.
         05 LINE 01 COL 02 PIC X(60) VALUE ALL"=".
         05 LINE 02 COL 15 VALUE "STOCK PORTFOLIO SYSTEM".
         05 LINE 03 COL 02 PIC X(60) VALUE ALL"=".
         05 LINE 04 COL 02 VALUE "ENTER CHOICE:".
         05 WS-USER-CHOICE LINE 04 COL 16 PIC 9(01) TO USER-CHOICE.
         05 LINE 04 COL 20 REVERSE-VIDEO
                        VALUE "  [1]SEARCH [2]BUY [9]EXIT [0]HOME  ".
         05 LINE 06 COL 02 VALUE "STOCK SYMBOL:".
         05 STOCK-SYMBOL LINE 06 COL 16 PIC X(07) TO STOCK-SYMBOL-IO.
         05 LINE 06 COL 26 VALUE "#SHARES:".
         05 SHARES LINE 06 COL 35 PIC ZZZZZ TO WS-SHARES.
      *--------------------------------------------------------------
         05 LINE 07 COL 02 PIC X(60) VALUE ALL"-".
         05 LINE 08 COL 02 PIC X(40) VALUE "STOCK SYMBOL".
         05 LINE 08 COL 20 PIC X(40) VALUE "#SHARES".
         05 LINE 08 COL 35 PIC X(40) VALUE "AVG COST/SHARE".
         05 MESSAGE-DISPLAY.
            10 LINE 26 COL 02        PIC X(50) FROM WS-MESSAGE01.
         05 LINE 29 COL 02           PIC X(60) VALUE ALL"=".

       *> Portfolio record display format.
       01 PRINT-PORTFOLIO-RECORD.
         05 LINE WS-LINE COL 06 PIC X(07) FROM STOCK-SYMBOL-IO.
         05 LINE WS-LINE COL 20 PIC ZZZZ9 FROM SHARES-IO.
         05 LINE WS-LINE COL 38 PIC $Z,ZZ9.99
                                         FROM AVG-COST-PER-SHARE-IO.
       *> Audit trail display section.
       01 AUDIT-TRAIL-SECTION.
         05 LINE 27 COL 02           PIC X(50) FROM WS-MESSAGE05.
         05 LINE 28 COL 02 VALUE "STOCK RECORDS READ:".
         05 LINE 28 COL 21           PIC ZZ9   FROM RECORDS-READ.
         05 LINE 28 COL 28 VALUE "STOCK RECORDS WRITTEN:".
         05 LINE 28 COL 49           PIC ZZ9   FROM RECORDS-WRITTEN.

       *> Blank audit section for clearing.
       01 BLANK-AUDIT-SECTION.
         05 LINE 27 COL 02 PIC X(60) VALUE SPACES.
         05 LINE 28 COL 02 PIC X(60) VALUE SPACES.

      ******************************************************************
       PROCEDURE DIVISION.
      ******************************************************************
      ******************************************************************
       100-PROCESS-DATA.
       *> Main control routine.
      ******************************************************************
         PERFORM 210-INITIALISE-RTN.
         PERFORM 240-SCREEN-MANAGEMENT UNTIL EXIT-9.
         PERFORM 290-TERMINATE-RTN.
         STOP RUN.
      ******************************************************************
       210-INITIALISE-RTN.
       *> Initialize files and load stock data.
      ******************************************************************
         PERFORM 310-OPEN-FILES.
         PERFORM 320-READ-STOCK-RECORDS
                 VARYING SUB-1 FROM 1 BY 1
                 UNTIL SUB-1 > 20 OR EOF-YES.

         IF RECORDS-READ = 0
             MOVE "NO DATA IN THE STOCKS FILE. " TO WS-MESSAGE05
         ELSE
             MOVE "STOCKS LOADED TO THE TABLE:"  TO WS-MESSAGE05
         END-IF.

         SET EOF-NO TO TRUE.
         PERFORM 330-INITIAL-DISPLAY-SCREENS.

      ******************************************************************
       240-SCREEN-MANAGEMENT.
       *> Handle user menu choices.
      ******************************************************************
         ACCEPT WS-USER-CHOICE.

         MOVE BLANK-LINE TO WS-MESSAGE01
         DISPLAY BLANK-AUDIT-SECTION.

         EVALUATE TRUE
           WHEN HOME-0
                MOVE SPACE TO WS-MESSAGE01
                DISPLAY MAIN-SCREEN
                PERFORM 430-READ-PORTFOLIO-DATA
           WHEN SEARCH-1
                PERFORM 341-SEARCH-PORTFOLIO
           WHEN BUY-2
                PERFORM 342-BUY-STOCK
           WHEN EXIT-9
                MOVE "Press ENTER to exit..."     TO WS-MESSAGE01
                DISPLAY MESSAGE-DISPLAY
                ACCEPT WS-MESSAGE01
           WHEN OTHER
                MOVE "INVALID CHOICE!!TRY AGAIN." TO WS-MESSAGE01
                DISPLAY MESSAGE-DISPLAY
         END-EVALUATE.

         IF SEARCH-1 OR BUY-2
            PERFORM 350-RESET-VARIABLES
            DISPLAY MAIN-SCREEN
         END-IF.
      ******************************************************************
       290-TERMINATE-RTN.
       *> Close files and terminate.
      ******************************************************************
         PERFORM 399-CLOSE-FILES.

      ******************************************************************
       310-OPEN-FILES.
       *> Open files with error checking.
      ******************************************************************
         OPEN INPUT STOCKS-IN.
         OPEN I-O   PORTFOLIO-IO.

         IF STATUS-STOCK NOT = "00"
           STRING
             "ERROR OPENING STOCKS.TXT. STATUS: "
             STATUS-STOCK
             DELIMITED BY SIZE INTO WS-MESSAGE01
           END-STRING
           STOP RUN
         END-IF.
         IF STATUS-PORTFOLIO NOT = "00"
           STRING
             "ERROR OPENING PORTFOLIO-INDEXED.DAT. STATUS: "
             STATUS-PORTFOLIO
             DELIMITED BY SIZE INTO WS-MESSAGE01
           END-STRING
           STOP RUN
         END-IF.
      ******************************************************************
       320-READ-STOCK-RECORDS.
       *> Load stock data into table.
      ******************************************************************
         READ STOCKS-IN
           AT END
             SET EOF-YES TO TRUE
           NOT AT END
             ADD 1 TO RECORDS-READ
             PERFORM 420-LOAD-STOCKS-TABLE
         END-READ.
      ******************************************************************
       330-INITIAL-DISPLAY-SCREENS.
       *> Set up initial screen display.
      ******************************************************************
         DISPLAY MAIN-SCREEN.
         PERFORM 430-READ-PORTFOLIO-DATA.
         DISPLAY AUDIT-TRAIL-SECTION.
      ******************************************************************
       341-SEARCH-PORTFOLIO.
       *> Search for portfolio record.
      ******************************************************************
         ACCEPT STOCK-SYMBOL.

         IF STOCK-SYMBOL = SPACES
            MOVE "SYMBOL REQUIRED FOR SEARCH" TO WS-MESSAGE01
            DISPLAY MESSAGE-DISPLAY
         ELSE
             PERFORM 450-CLEAN-PORTFOLIO-DISPLAY
             MOVE WS-START-LINE TO WS-LINE
             READ PORTFOLIO-IO
                 INVALID KEY
                     STRING
                         "PORTFOLIO '", STOCK-SYMBOL-IO, "' NOT FOUND"
                         DELIMITED BY SIZE INTO WS-MESSAGE01
                     END-STRING
                     DISPLAY MESSAGE-DISPLAY
                 NOT INVALID KEY
                     DISPLAY PRINT-PORTFOLIO-RECORD
                     MOVE "SEARCH COMPLETED." TO WS-MESSAGE01
                     DISPLAY MESSAGE-DISPLAY
             END-READ
         END-IF.
      ******************************************************************
       342-BUY-STOCK.
        *> Process stock purchase.
      ******************************************************************
         ACCEPT STOCK-SYMBOL.
         ACCEPT SHARES.

         MOVE SHARES TO WS-SHARES.
         IF STOCK-SYMBOL = SPACES OR SHARES = 0
           MOVE "BOTH SYMBOL AND SHARES REQUIRED FOR BUYING STOCKS."
                                                  TO WS-MESSAGE01
           DISPLAY MESSAGE-DISPLAY
         ELSE
           READ PORTFOLIO-IO
             INVALID KEY
                 PERFORM 440-MATCHING-STOCK-PRICE
                 IF NOT EXIT-YES
                    PERFORM 450-CLEAN-PORTFOLIO-DISPLAY
                    MOVE WS-START-LINE TO WS-LINE
                    PERFORM 460-ADD-PORTFOLIO-RECORD
                 END-IF
             NOT INVALID KEY
                 PERFORM 440-MATCHING-STOCK-PRICE
                 IF NOT EXIT-YES
                    PERFORM 450-CLEAN-PORTFOLIO-DISPLAY
                    MOVE WS-START-LINE TO WS-LINE
                    PERFORM 470-UPDATE-PORTFOLIO-RECORD
                 END-IF
           END-READ
         END-IF.

         IF EXIT-YES
            STRING
               "STOCK DOES NOT EXIST, TRY OTHERS."
               DELIMITED BY SIZE INTO WS-MESSAGE01
            END-STRING
            DISPLAY MESSAGE-DISPLAY
         END-IF.
      ******************************************************************
       350-RESET-VARIABLES.
       *> Clear input variables.
      ******************************************************************
         MOVE 0      TO WS-USER-CHOICE.
         MOVE SPACE  TO STOCK-SYMBOL.
         MOVE 0      TO SHARES.
         SET EXIT-NO TO TRUE.
      ******************************************************************
       399-CLOSE-FILES.
       *> Close all open files.
      ******************************************************************
         CLOSE STOCKS-IN PORTFOLIO-IO.

      ******************************************************************
       420-LOAD-STOCKS-TABLE.
       *> Move record to table.
      ******************************************************************
         MOVE STOCK-SYMBOL-IN  TO T-STOCK-SYMBOL(SUB-1).
         MOVE STOCK-NAME-IN    TO T-STOCK-NAME(SUB-1).
         MOVE CLOSING-PRICE-IN TO T-CLOSING-PRICE(SUB-1).
         ADD  1                TO RECORDS-WRITTEN.
      ******************************************************************
       430-READ-PORTFOLIO-DATA.
       *> Read and display portfolio records.
      ******************************************************************
         INITIALIZE STOCK-SYMBOL-IO.
         START PORTFOLIO-IO KEY >= STOCK-SYMBOL-IO
             INVALID KEY
               MOVE "NO PORTFOLIO RECORD." TO WS-MESSAGE01
               DISPLAY MESSAGE-DISPLAY
             NOT INVALID KEY
               PERFORM 530-DISPLAY-PORTFOLIO
                       VARYING WS-LINE FROM WS-START-LINE BY 2
                       UNTIL WS-LINE > WS-END-LINE OR EOF-YES
         END-START.

         SET EOF-NO TO TRUE.
      ******************************************************************
       440-MATCHING-STOCK-PRICE.
       *> Find stock price in table.
      ******************************************************************
         SEARCH ALL STOCKS-VALUE
           AT END
              MOVE "STOCK NOT FOUND."             TO WS-MESSAGE01
              DISPLAY MESSAGE-DISPLAY
              SET EXIT-YES                        TO TRUE
           WHEN T-STOCK-SYMBOL(STOCK-INDEX) EQUAL TO STOCK-SYMBOL
              MOVE T-STOCK-NAME(STOCK-INDEX)      TO WS-STOCK-NAME
              MOVE T-CLOSING-PRICE(STOCK-INDEX)   TO WS-CLOSING-PRICE
         END-SEARCH.
      ******************************************************************
       450-CLEAN-PORTFOLIO-DISPLAY.
       *> Clear portfolio display area.
      ******************************************************************
         PERFORM VARYING WS-LINE
                 FROM WS-START-LINE BY 1
                 UNTIL WS-LINE > WS-END-LINE
            DISPLAY BLANK-LINE LINE WS-LINE COL 02
         END-PERFORM.
      ******************************************************************
       460-ADD-PORTFOLIO-RECORD.
       *> Create new portfolio record.
      ******************************************************************
         COMPUTE AVG-COST-PER-SHARE-IO ROUNDED =
                 (WS-SHARES* WS-CLOSING-PRICE) / WS-SHARES.
         MOVE WS-SHARES TO SHARES-IO.
         WRITE PORTFOLIO-RECORD-IO
           INVALID KEY
              MOVE "INVALID STOCK STMBOL, STOCK NOT PURCHASED"
                                                      TO WS-MESSAGE01
              DISPLAY MESSAGE-DISPLAY
           NOT INVALID KEY
              DISPLAY PRINT-PORTFOLIO-RECORD
              MOVE "PURCHASE SUCCEEDED. RECORD ADDED."
                                                      TO WS-MESSAGE01
              DISPLAY MESSAGE-DISPLAY
         END-WRITE.
      ******************************************************************
       470-UPDATE-PORTFOLIO-RECORD.
       *> Update existing portfolio record.
      ******************************************************************
         COMPUTE TOTALSHARES = SHARES-IO + WS-SHARES.
         COMPUTE AVG-COST-PER-SHARE-IO ROUNDED =
                ((SHARES-IO * AVG-COST-PER-SHARE-IO) +
                 (WS-SHARES * WS-CLOSING-PRICE)) / TOTALSHARES.
         MOVE TOTALSHARES TO SHARES-IO.

         REWRITE PORTFOLIO-RECORD-IO
           INVALID KEY
              MOVE "INVALID STOCK STMBOL, STOCK NOT UPDATED."
                                                      TO WS-MESSAGE01
              DISPLAY MESSAGE-DISPLAY
           NOT INVALID KEY
              DISPLAY PRINT-PORTFOLIO-RECORD
              MOVE "PURCHASE WAS SUCCESSFUL. RECORD UPDATED."
                                                      TO WS-MESSAGE01
              DISPLAY MESSAGE-DISPLAY
         END-REWRITE.
      ******************************************************************
       530-DISPLAY-PORTFOLIO.
       *> Display next portfolio record.
      ******************************************************************
         READ PORTFOLIO-IO NEXT RECORD
           AT END
              SET EOF-YES TO TRUE
           NOT AT END
              DISPLAY PRINT-PORTFOLIO-RECORD
         END-READ.
      ******************************************************************
       END PROGRAM P3B.
      ******************************************************************
