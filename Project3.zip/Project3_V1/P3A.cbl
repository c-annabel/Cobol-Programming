      ******************************************************************
      * Author & ID: CHENG, Annabel  (041146557),
      *              ZHAO,  LingFeng (041162790),
      *              GURTH, Benjamin (041127769).
      * Course and Section: CST8283 311
      * Date: 2025-07-27
      * Purpose: PROJECT 3 A CONVERT TO INDEXED SEQ. FILE
      * Tectonics: cobc
      ******************************************************************
       IDENTIFICATION DIVISION.
      ******************************************************************
       PROGRAM-ID. P3A.
      ******************************************************************
       ENVIRONMENT DIVISION.
      ******************************************************************
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
      *> Input File
         SELECT PORTFOLIO-IN
           ASSIGN TO "../PORTFOLIO.TXT"
           ORGANIZATION IS LINE SEQUENTIAL
           FILE STATUS  IS STATUS-IN-FIELD.
      *> Output Indexed File
         SELECT PORTFOLIO-OUT
           ASSIGN TO "../PORTFOLIO-INDEXED.DAT"
           ORGANIZATION IS INDEXED
           ACCESS MODE  IS SEQUENTIAL
           RECORD KEY   IS STOCK-SYMBOL-OUT
           FILE STATUS  IS STATUS-OUT-FIELD.
      ******************************************************************
       DATA DIVISION.
      ******************************************************************
       FILE SECTION.
       FD PORTFOLIO-IN.
       *> Input file structure for the portfolio text data.
       01 PORTFOLIO-RECORD-IN.
           05 STOCK-SYMBOL-IN          PIC X(07).
           05 SHARES-IN                PIC 9(05).
           05 AVG-COST-PER-SHARE-IN    PIC 9(04)V99.

       FD PORTFOLIO-OUT.
       *> Output file structure for the indexed portfolio data.
       01 PORTFOLIO-RECORD-OUT.
           05 STOCK-SYMBOL-OUT         PIC X(07).
           05 SHARES-OUT               PIC 9(05).
           05 AVG-COST-PER-SHARE-OUT   PIC 9(04)V99.

       WORKING-STORAGE SECTION.
       *> File control code.
       01 STATUS-IN-FIELD              PIC X(02).
       01 STATUS-OUT-FIELD             PIC X(02).
       01 EOF-FLAG                     PIC X(01)  VALUE 'N'.
          88 EOF-YES                              VALUE 'Y'.

       *> Output formatting.
       01 DASH-LINE                    PIC X(70)  VALUE ALL "=".

       *> Audit trail counters.
       01 AUDIT-TRAIL-IN.
          05 RECORDS-READ              PIC 9(03)  VALUE ZERO.
          05 RECORDS-WRITTEN           PIC 9(03)  VALUE ZERO.
       01 AUDIT-TRAIL-OUT.
          05 PRINT-RECORDS-READ        PIC ZZ9.
          05 PRINT-RECORDS-WRITTEN     PIC ZZ9.
      ******************************************************************
       PROCEDURE DIVISION.
      ******************************************************************
      *> Main control flow for the program.
      ******************************************************************
       100-PROCESS-DATA.
      ******************************************************************
           PERFORM 210-INITIALISE-RTN.
           PERFORM 220-LOAD-STOCK-RECORDS UNTIL EOF-YES.
           PERFORM 290-TERMINATE-RTN.
           STOP RUN.

      *> Opens the files and initializes fields.
      ******************************************************************
       210-INITIALISE-RTN.
      ******************************************************************
           PERFORM 310-OPEN-FILES.

      *> Reads input and writes to indexed output until EOF.
      ******************************************************************
       220-LOAD-STOCK-RECORDS.
      ******************************************************************
           READ PORTFOLIO-IN
             AT END
               SET EOF-YES TO TRUE
               IF RECORDS-READ = 0
                  DISPLAY "NO DATA IN THE PORTFOLIO FILE. "
               END-IF
             NOT AT END
               ADD 1 TO RECORDS-READ
               MOVE PORTFOLIO-RECORD-IN TO PORTFOLIO-RECORD-OUT
               PERFORM 320-WRITE-INDEXED-FILE
           END-READ.

      *> Terminates the program. Print audit and close files.
      ******************************************************************
       290-TERMINATE-RTN.
      ******************************************************************
           PERFORM 390-DISPLAY-AUDIT-TRAIL
           PERFORM 399-CLOSE-FILES.

      *> Open files and validate the fields.
      ******************************************************************
       310-OPEN-FILES.
      ******************************************************************
           OPEN INPUT  PORTFOLIO-IN.
           OPEN OUTPUT PORTFOLIO-OUT.

           IF STATUS-IN-FIELD NOT = "00"
             DISPLAY "ERROR OPENING PORTFOLIO.TXT. STATUS: ",
                     STATUS-IN-FIELD
             STOP RUN
           END-IF.
           IF STATUS-OUT-FIELD NOT = "00"
             DISPLAY "ERROR OPENING PORTFOLIO-INDEXED.DAT. STATUS: ",
                     STATUS-OUT-FIELD
             STOP RUN
           END-IF.

      *> Write records into indexed file.
      ******************************************************************
       320-WRITE-INDEXED-FILE.
      ******************************************************************
           WRITE PORTFOLIO-RECORD-OUT
              INVALID KEY
                DISPLAY STOCK-SYMBOL-OUT
                        " : INVALID KEY, RECORD NOT WRITTEN. STATUS:"
                        STATUS-OUT-FIELD
              NOT INVALID KEY
                ADD 1 TO RECORDS-WRITTEN
           END-WRITE.

      *> Output audit info.
      ******************************************************************
       390-DISPLAY-AUDIT-TRAIL.
      ******************************************************************
           MOVE RECORDS-READ    TO PRINT-RECORDS-READ.
           MOVE RECORDS-WRITTEN TO PRINT-RECORDS-WRITTEN.
           DISPLAY "RECORDS READ: ", PRINT-RECORDS-READ.
           DISPLAY "RECORDS WRITTEN: ", PRINT-RECORDS-WRITTEN.
           DISPLAY DASH-LINE.

      *> Close file streams.
      ******************************************************************
       399-CLOSE-FILES.
      ******************************************************************
           CLOSE PORTFOLIO-IN PORTFOLIO-OUT.
      ******************************************************************
       END PROGRAM P3A.
      ******************************************************************
